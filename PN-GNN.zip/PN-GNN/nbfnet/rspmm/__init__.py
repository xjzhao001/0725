from .rspmm import generalized_rspmm
